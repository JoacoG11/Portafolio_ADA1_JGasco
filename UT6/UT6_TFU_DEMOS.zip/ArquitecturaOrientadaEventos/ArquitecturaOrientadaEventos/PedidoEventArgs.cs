namespace ArquitecturaOrientadaEventos;

public class PedidoEventArgs
{
    public int PedidoId { get; set; }
    public string Cliente { get; set; }
    public decimal Monto { get; set; }
}
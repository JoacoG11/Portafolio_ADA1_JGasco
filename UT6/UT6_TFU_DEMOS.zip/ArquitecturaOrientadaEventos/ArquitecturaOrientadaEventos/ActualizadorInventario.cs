namespace ArquitecturaOrientadaEventos;

public class ActualizadorInventario
{
    public void Suscribir(SistemaPedidos sistemaPedidos)
    {
        sistemaPedidos.PedidoCreado += ActualizarInventario;
    }

    private void ActualizarInventario(object sender, PedidoEventArgs e)
    {
        // Simular la actualización del inventario
        Console.WriteLine($"Actualizando inventario para el pedido #{e.PedidoId}.");
    }
}
namespace ArquitecturaOrientadaEventos;

public class GeneradorFactura
{
    public void Suscribir(SistemaPedidos sistemaPedidos)
    {
        sistemaPedidos.PedidoCreado += GenerarFactura;
    }

    private void GenerarFactura(object sender, PedidoEventArgs e)
    {
        // Simular la generación de una factura
        Console.WriteLine($"Generando factura: Pedido #{e.PedidoId} para el cliente {e.Cliente} con monto {e.Monto:C}.");
    }
}
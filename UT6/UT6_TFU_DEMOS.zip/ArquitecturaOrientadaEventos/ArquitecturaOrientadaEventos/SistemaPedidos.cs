namespace ArquitecturaOrientadaEventos;

public class SistemaPedidos
{
    // Definir el delegado
    public delegate void PedidoCreadoHandler(object sender, PedidoEventArgs e);
    
    // Definir el evento basado en el delegado
    public event PedidoCreadoHandler PedidoCreado;

    public void CrearPedido(int pedidoId, string cliente, decimal monto)
    {
        // Disparar el evento si hay suscriptores
        PedidoCreado?.Invoke(this, new PedidoEventArgs { PedidoId = pedidoId, Cliente = cliente, Monto = monto });
    }
}
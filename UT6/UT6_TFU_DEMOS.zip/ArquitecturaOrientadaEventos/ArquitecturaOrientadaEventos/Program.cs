﻿// See https://aka.ms/new-console-template for more information
using ArquitecturaOrientadaEventos;

// Crear el sistema de pedidos
SistemaPedidos sistemaPedidos = new SistemaPedidos();

// Crear los consumidores
NotificadorEmail notificadorEmail = new NotificadorEmail();
GeneradorFactura generadorFactura = new GeneradorFactura();
ActualizadorInventario actualizadorInventario = new ActualizadorInventario();

// Suscribir los consumidores al sistema de pedidos
notificadorEmail.Suscribir(sistemaPedidos);
generadorFactura.Suscribir(sistemaPedidos);
actualizadorInventario.Suscribir(sistemaPedidos);

// Crear un nuevo pedido
sistemaPedidos.CrearPedido(1, "Juan Pérez", 100.50m);
Console.WriteLine("\n");
sistemaPedidos.CrearPedido(2, "Pablo Picaso", 125m);
Console.WriteLine("\n");
sistemaPedidos.CrearPedido(3, "Bruno Alin", 80m);
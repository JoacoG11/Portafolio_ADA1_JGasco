namespace ArquitecturaOrientadaEventos;

public class NotificadorEmail
{
    public void Suscribir(SistemaPedidos sistemaPedidos)
    {
        sistemaPedidos.PedidoCreado += EnviarEmail;
    }

    private void EnviarEmail(object sender, PedidoEventArgs e)
    {
        // Simular el envío de un email
        Console.WriteLine($"Enviando email: Pedido #{e.PedidoId} creado para el cliente {e.Cliente} con monto {e.Monto:C}.");
    }
}
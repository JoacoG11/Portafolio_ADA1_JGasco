Este ejemplo simulará un sistema de pedidos donde se generan eventos cuando se crea un nuevo pedido y diferentes componentes del sistema reaccionan a estos eventos.

- Primero, definimos los eventos y los delegados necesarios para el sistema.

- Creamos diferentes consumidores que reaccionarán a los eventos de creación de pedidos.

- Creamos una clase Program para ejecutar el sistema de pedidos, suscribiendo a los consumidores y generando un nuevo pedido.

1. Definición del Evento: En la clase SistemaPedidos, definimos un delegado PedidoCreadoHandler y un evento PedidoCreado basado en ese delegado. La clase también tiene un método CrearPedido que dispara el evento cuando se crea un nuevo pedido.

2. Suscripción al Evento: Creamos tres clases consumidoras (NotificadorEmail, GeneradorFactura, ActualizadorInventario). Cada clase tiene un método Suscribir que se utiliza para suscribirse al evento PedidoCreado del SistemaPedidos.

3. Manejo del Evento: Cada clase consumidora define un método para manejar el evento. Por ejemplo, NotificadorEmail tiene un método EnviarEmail que simula el envío de un correo electrónico cuando se crea un nuevo pedido. Similarmente, GeneradorFactura y ActualizadorInventario tienen métodos para generar facturas y actualizar el inventario, respectivamente.

4. Ejecución del Ejemplo: En la clase Program, creamos una instancia del SistemaPedidos y de cada consumidor. Luego, suscribimos a los consumidores al evento PedidoCreado y finalmente creamos un nuevo pedido, lo cual dispara el evento y activa los manejadores de eventos en cada consumidor.

- Evento: Una señal o mensaje que indica que una acción o condición específica ha ocurrido dentro del sistema.

- Delegado: Un tipo que representa referencias a métodos con una lista específica de parámetros y un tipo de retorno, permitiendo la asignación de métodos a eventos.

- Suscripción al Evento: El proceso mediante el cual un consumidor se registra para recibir notificaciones cuando ocurre un evento específico.

- Consumidor: Un componente del sistema que reacciona a los eventos, ejecutando acciones específicas cuando se disparan esos eventos.
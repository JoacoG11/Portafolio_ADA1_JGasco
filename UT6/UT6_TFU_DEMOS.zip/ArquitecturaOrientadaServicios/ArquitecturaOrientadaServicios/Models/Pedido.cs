namespace ArquitecturaOrientadaServicios.Models;

public class Pedido
{
    public int Id { get; set; }
    public string NombreCliente { get; set; }
    public decimal Monto { get; set; }
}
using ArquitecturaOrientadaServicios.Models;

namespace ArquitecturaOrientadaServicios.Repositories;

public class PedidoRepository: IPedidoRepository
{
    private static List<Pedido> pedidos = new List<Pedido>();

    public IEnumerable<Pedido> GetAll()
    {
        return pedidos;
    }

    public Pedido GetById(int id)
    {
        return pedidos.FirstOrDefault(p => p.Id == id);
    }

    public void Add(Pedido pedido)
    {
        pedido.Id = pedidos.Count > 0 ? pedidos.Max(p => p.Id) + 1 : 1;
        pedidos.Add(pedido);
    }

    public void Update(Pedido pedido)
    {
        var existingPedido = pedidos.FirstOrDefault(p => p.Id == pedido.Id);
        if (existingPedido != null)
        {
            existingPedido.NombreCliente = pedido.NombreCliente;
            existingPedido.Monto = pedido.Monto;
        }
    }

    public void Delete(int id)
    {
        var pedido = pedidos.FirstOrDefault(p => p.Id == id);
        if (pedido != null)
        {
            pedidos.Remove(pedido);
        }
    }
}
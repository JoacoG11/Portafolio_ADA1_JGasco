using ArquitecturaOrientadaServicios.Models;
using ArquitecturaOrientadaServicios.Repositories;
using Microsoft.AspNetCore.Mvc;

namespace ArquitecturaOrientadaServicios.Controllers;

[ApiController]
[Route("pedido")]
public class PedidoController : ControllerBase
{  
    private readonly IPedidoRepository _pedidoRepository;

    public PedidoController(IPedidoRepository pedidoRepository)
    {
        _pedidoRepository = pedidoRepository;
    }

    [HttpGet]
    public ActionResult<IEnumerable<Pedido>> Get()
    {
        return Ok(_pedidoRepository.GetAll());
    }

    [HttpGet("{id}")]
    public ActionResult<Pedido> Get(int id)
    {
        var pedido = _pedidoRepository.GetById(id);
        if (pedido == null)
            return NotFound();
        return Ok(pedido);
    }

    [HttpPost]
    public ActionResult<Pedido> Post(Pedido pedido)
    {
        _pedidoRepository.Add(pedido);
        return CreatedAtAction(nameof(Get), new { id = pedido.Id }, pedido);
    }

    [HttpPut("{id}")]
    public IActionResult Put(int id, Pedido pedido)
    {
        var existingPedido = _pedidoRepository.GetById(id);
        if (existingPedido == null)
            return NotFound();

        _pedidoRepository.Update(pedido);

        return NoContent();
    }

    [HttpDelete("{id}")]
    public IActionResult Delete(int id)
    {
        var pedido = _pedidoRepository.GetById(id);
        if (pedido == null)
            return NotFound();

        _pedidoRepository.Delete(id);

        return NoContent();
    }
}